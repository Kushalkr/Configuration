# base16-gnome-terminal

Base16 for Gnome Terminal

## Installation
Firstly source the scheme file of your choosing: 

    source .config/base16-gnome-terminal/base16-default.dark.sh

Next, restart or open Gnome Terminal. Right click on the terminal and select profiles the menu that pops-up. The scheme you just sourced should be available for selection.
